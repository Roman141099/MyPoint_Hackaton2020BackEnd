create
    definer = u1063682_one_cod@`%` procedure getOrders()
begin
    select o.id          as id_order,
           o.courier_id  as id_courier,
           c.name        as name_courier,
           o.accepted    as accepted,
           o.order_taken as order_taken
    from (select id,
                 courier_id,
                 accepted,
                 order_taken
          from orders
          where !order_finished) o
             inner join couriers c on o.courier_id = c.id;
end;

