create
    definer = u1063682_one_cod@`%` procedure checkOrder(IN id_order int)
begin
    select o.id             as id_order,
           c.id             as id_courier,
           c.last_latitude  as lat_courier,
           c.last_longitude as lon_courier,
           o.order_taken    as order_taken,
           o.acceptance     as acceptance,
           o.distance       as distance,
           o.travel_time    as travel_time,
           o.path           as path
    from (select o.id          as id,
                 o.acceptance  as acceptance,
                 o.courier_id  as courier_id,
                 o.order_taken as order_taken,
                 c.distance    as distance,
                 c.travel_time as travel_time,
                 c.path        as path
          from orders o
                   inner join checkOrder c on o.id = c.id
          where id = id_order) as o
             inner join couriers c on c.id = o.courier_id;
end;

