create
    definer = u1063682_one_cod@`%` procedure countUsers()
begin
    select o.count as online, b.count as not_busy
    from (select count(id) as count from couriers where online) o,
         (select count(id) as count from couriers where !busy and online) b;
end;

